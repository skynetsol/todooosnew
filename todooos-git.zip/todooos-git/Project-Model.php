<?php

namespace App\Models;

use App\Jobs\SendRequestEmail;
use App\Library\Strings;
use App\User;
use Auth;
use DB;
use File;
use Illuminate\Database\Eloquent\Model;
use Mail;
use Session;
use General;
use Timezone;

class Project extends Model
{
    use Cachable;

    use Notifiable;
    protected $i = 0;
    protected $newdata = array();

    protected $j = 0;
    protected $newdata1 = array();

    protected $k = 0;
    protected $newdata2 = array();

    protected $l = 0;
    protected $newdata3 = array();

    public function __construct()
	{
		$this->general = new General;
	}

    public function getProjects($companyId = false,$archived = false)
    {
        $this->i = 0;
        $this->newdata = array();
        $array = array();
        $strQuery = '';
        $allProjectIds = array();

        $projects = DB::table('projects')
            ->join('invites', 'projects.projectid', '=', 'invites.projectid')
            ->where([['invites.userid', Auth::user()->id], ['invites.deleted_at', '0000-00-00 00:00:00'], ['projects.archived', $archived], ['projects.companyid', $companyId], ['projects.deleted_by', 0]])
            ->orderBy('projects.projectname')
            ->get()->toArray();

        if (count($projects) > 0) {
            $prevFirstAlpha = '';
            $nextProjectId = 0;
            $nextAlpha = '';
            foreach ($projects as $index=>$project) {
                $totalPie = 0;
                $totalTasks = DB::table('tasks')->where([['projectid', $project->projectid], ['labelid', '!=', 0], ['deleted_at', null]])->count();
                $totalOpenTasks = DB::table('tasks')->where([['projectid', $project->projectid], ['completed', 0], ['labelid', '!=', 0], ['deleted_at', null]])->count();
                $totalClose = $totalTasks - $totalOpenTasks;
                if ($totalTasks > 0) {
                    $totalPie = ($totalClose / $totalTasks) * 10;
                }
                $totalTime = DB::select("SELECT  SEC_TO_TIME( SUM( TIME_TO_SEC( `working_time` ) ) ) AS timetdlSum FROM todo_comments where projectid = " . $project->projectid);
                $commentInfo = DB::table('comments')->where('projectid', $project->projectid)->orderBy('commentid', 'desc')->first();
                $commentArray = json_decode(json_encode($commentInfo), true);

                if( isset($projects[$index+1]->projectid) && array_key_exists($index + 1, $projects )) {
                    $nextProjectId = $projects[$index+1]->projectid;
                    $nextAlpha = strtoupper(substr($projects[$index+1]->projectname, 0, 1));
                } 
                $firstAlpha = strtoupper(substr($project->projectname, 0, 1));
                if($archived == 0){
                    if(Auth::user()->listingtype == 1){
                        $array = array(
                            "projectid" => $project->projectid,
                            "nextprojectid" => $nextProjectId,
                            "nextAlpha" => $nextAlpha,
                            "projectname" => $project->projectname,
                            "seoname" => $project->seoname,
                            "seourl" => $project->seourl,
                            "projectstatus" => DB::table('projects_status')->where([['projectstatusid', $project->projectstatus]])->value('statusname'),
                            "firstalpha" => $firstAlpha,
                            "timeentry" => $project->timeentry,
                            "favourite" => $project->favourite,
                            "created_at" => $project->created_at,
                            "totaltime" => $totalTime[0]->timetdlSum,
                            "totaltasks" => $totalTasks,
                            "totalopentasks" => $totalOpenTasks,
                            "totalpie" => round($totalPie),
                            "inviteusers" => $this->inviteUsers($project->projectid),
                            "inviteclients" => $this->inviteClientUsers($project->projectid),
                            "invitemanagers" => $this->inviteManagerUsers($project->projectid),
                            "lastupdate" => (isset($commentArray['created_at']) ? 'Last updated ' . date("M d D h:i a", strtotime($this->general->converttimezoneFromUTCWTZ($commentArray['created_at']))) : 'Project created at ' . date("M d D h:i a", strtotime($project->created_at))),
                            "prevFirstAlpha" => ($prevFirstAlpha != $firstAlpha ? '' : $firstAlpha),
                        );
                    }else{
                        $array = array(
                            "projectid" => $project->projectid,
                            "nextprojectid" => $nextProjectId,
                            "nextAlpha" => $nextAlpha,
                            "projectname" => $project->projectname,
                            "seoname" => $project->seoname,
                            "seourl" => $project->seourl,
                            "projectstatus" => DB::table('projects_status')->where([['projectstatusid', $project->projectstatus]])->value('statusname'),
                            "firstalpha" => $firstAlpha,
                            "timeentry" => $project->timeentry,
                            "favourite" => $project->favourite,
                            "created_at" => $project->created_at,
                            "totaltime" => $totalTime[0]->timetdlSum,
                            "totaltasks" => $totalTasks,
                            "totalopentasks" => $totalOpenTasks,
                            "totalpie" => round($totalPie),
                            "inviteclients" => $this->inviteClientUsers($project->projectid),
                            "invitemanagers" => $this->inviteManagerUsers($project->projectid),
                            "lastupdate" => (isset($commentArray['created_at']) ? 'Last updated ' . date("M d D h:i a", strtotime($this->general->converttimezoneFromUTCWTZ($commentArray['created_at']))) : 'Project created at ' . date("M d D h:i a", strtotime($project->created_at))),
                            "prevFirstAlpha" => ($prevFirstAlpha != $firstAlpha ? '' : $firstAlpha),
                        );
                    }
                }else{
                    $array = array(
                        "projectid" => $project->projectid,
                        "nextprojectid" => $nextProjectId,
                        "nextAlpha" => $nextAlpha,
                        "projectname" => $project->projectname,
                        "seoname" => $project->seoname,
                        "seourl" => $project->seourl,
                        "projectstatus" => DB::table('projects_status')->where([['projectstatusid', $project->projectstatus]])->value('statusname'),
                        "firstalpha" => $firstAlpha,
                        "timeentry" => $project->timeentry,
                        "favourite" => $project->favourite,
                        "created_at" => $project->created_at,
                        "totaltime" => $totalTime[0]->timetdlSum,
                        "totaltasks" => $totalTasks,
                        "totalopentasks" => $totalOpenTasks,
                        "totalpie" => round($totalPie),
                        "lastupdate" => (isset($commentArray['created_at']) ? 'Last updated ' . date("M d D h:i a", strtotime($this->general->converttimezoneFromUTCWTZ($commentArray['created_at']))) : 'Project created at ' . date("M d D h:i a", strtotime($project->created_at))),
                        "prevFirstAlpha" => ($prevFirstAlpha != $firstAlpha ? '' : $firstAlpha),
                    ); 
                }
                $this->newdata[$this->i] = (object) $array;
                $this->i++;
                $prevFirstAlpha = $firstAlpha;
            }
        }
        return $this->newdata;
    }


    public function getAjaxProjects($request,$companyId = false)
    {
        $perpage = (int)$request->page + 1;
        $this->i = 0;
        $this->newdata = array();
        $array = array();
        $strQuery = '';
        $allProjectIds = array();
        $clientId = $request->clientid;
        $managerId = $request->managerid;
        $projectStatus= (isset($request->projectstatus) ? $request->projectstatus : 0) ;

        if ($clientId && $managerId) {
            $projectIdClientArr = DB::table('projects')
                ->join('invites', 'projects.projectid', '=', 'invites.projectid')
                ->where([['invites.userid', $clientId],['invites.userid', $managerId], ['invites.invitetype', 'C'],['invites.manager', '1'], ['invites.deleted_at', '0000-00-00 00:00:00'], ['projects.archived', 0], ['projects.companyid', $companyId], ['projects.deleted_by', 0]])
                ->pluck('projects.projectid')->toArray();
        }elseif ($clientId && $managerId == '0') {
            $projectIdClientArr = DB::table('projects')
                ->join('invites', 'projects.projectid', '=', 'invites.projectid')
                ->where([['invites.userid', $clientId], ['invites.invitetype', 'C'], ['invites.deleted_at', '0000-00-00 00:00:00'], ['projects.archived', 0], ['projects.companyid', $companyId], ['projects.deleted_by', 0]])
                ->pluck('projects.projectid')->toArray();
        }elseif ($clientId == '0' && $managerId) {
            $projectIdClientArr = DB::table('projects')
                ->join('invites', 'projects.projectid', '=', 'invites.projectid')
                ->where([['invites.userid', $managerId], ['invites.manager', '1'], ['invites.deleted_at', '0000-00-00 00:00:00'], ['projects.archived', 0], ['projects.companyid', $companyId], ['projects.deleted_by', 0]])
                ->pluck('projects.projectid')->toArray();
        }

        $projectIdAllArr = DB::table('projects')
        ->join('invites', 'projects.projectid', '=', 'invites.projectid')
        ->where([['invites.userid', Auth::user()->id], ['invites.deleted_at', '0000-00-00 00:00:00'], ['projects.archived', 0], ['projects.companyid', $companyId], ['projects.deleted_by', 0]])
        ->pluck('projects.projectid')
        ->toArray();

        $projectIdArr = (!empty($projectIdClientArr) ? array_intersect($projectIdClientArr, $projectIdAllArr) : $projectIdAllArr);
        $projectIds = (!empty($projectIdArr) ? implode(',', $projectIdArr) : "''");
        if ($projectIds != '') {
            $extQuery = ($projectStatus == 0 ? ' ' : ' and projectstatus = ' . $projectStatus);
            $strQuery = " (projectid in (" . $projectIds . ") and companyid =" . $companyId . " and archived = 0 " . $extQuery . " )";
        }
        $projects = DB::select("select projectid, projectname, seoname, seourl, created_at, timeentry, favourite, projectstatus from todo_projects where " . $strQuery . " and deleted_by = 0 order by projectname asc");
        if (count($projects) > 0) {
            $prevFirstAlpha = '';
            foreach ($projects as $index=>$project) {
                $totalPie = 0;
                $totalTasks = DB::table('tasks')->where([['projectid', $project->projectid], ['labelid', '!=', 0], ['deleted_at', null]])->count();
                $totalOpenTasks = DB::table('tasks')->where([['projectid', $project->projectid], ['completed', 0], ['labelid', '!=', 0], ['deleted_at', null]])->count();
                $totalClose = $totalTasks - $totalOpenTasks;
                if ($totalTasks > 0) {
                    $totalPie = ($totalClose / $totalTasks) * 10;
                }
                $totalTime = DB::select("SELECT  SEC_TO_TIME( SUM( TIME_TO_SEC( `working_time` ) ) ) AS timetdlSum FROM todo_comments where projectid = " . $project->projectid);
                $commentInfo = DB::table('comments')->where('projectid', $project->projectid)->orderBy('commentid', 'desc')->first();
                $commentArray = json_decode(json_encode($commentInfo), true);

                if(array_key_exists($index + 1, $projects )) {
                    $nextProjectId = $projects[$index+1]->projectid;
                    $nextAlpha = strtoupper(substr($projects[$index+1]->projectname, 0, 1));
                } 
                $firstAlpha = strtoupper(substr($project->projectname, 0, 1));
                if(Auth::user()->listingtype == 1){
                    $array = array(
                        "projectid" => $project->projectid,
                        "nextprojectid" => $nextProjectId,
                        "nextAlpha" => $nextAlpha,
                        "projectname" => $project->projectname,
                        "seoname" => $project->seoname,
                        "seourl" => $project->seourl,
                        "projectstatus" => DB::table('projects_status')->where([['projectstatusid', $project->projectstatus]])->value('statusname'),
                        "firstalpha" => $firstAlpha,
                        "timeentry" => $project->timeentry,
                        "favourite" => $project->favourite,
                        "created_at" => $project->created_at,
                        "totaltime" => $totalTime[0]->timetdlSum,
                        "totaltasks" => $totalTasks,
                        "totalopentasks" => $totalOpenTasks,
                        "totalpie" => round($totalPie),
                        "inviteusers" => $this->inviteUsers($project->projectid),
                        "inviteclients" => $this->inviteClientUsers($project->projectid),
                        "invitemanagers" => $this->inviteManagerUsers($project->projectid),
                        "lastupdate" => (isset($commentArray['created_at']) ? 'Last updated ' . date("M d D h:i a", strtotime($this->general->converttimezoneFromUTCWTZ($commentArray['created_at']))) : 'Project created at ' . date("M d D h:i a", strtotime($project->created_at))),
                        "prevFirstAlpha" => ($prevFirstAlpha != $firstAlpha ? '' : $firstAlpha),
                    );
                }else{
                    $array = array(
                        "projectid" => $project->projectid,
                        "nextprojectid" => $nextProjectId,
                        "nextAlpha" => $nextAlpha,
                        "projectname" => $project->projectname,
                        "seoname" => $project->seoname,
                        "seourl" => $project->seourl,
                        "projectstatus" => DB::table('projects_status')->where([['projectstatusid', $project->projectstatus]])->value('statusname'),
                        "firstalpha" => $firstAlpha,
                        "timeentry" => $project->timeentry,
                        "favourite" => $project->favourite,
                        "created_at" => $project->created_at,
                        "totaltime" => $totalTime[0]->timetdlSum,
                        "totaltasks" => $totalTasks,
                        "totalopentasks" => $totalOpenTasks,
                        "totalpie" => round($totalPie),
                        "inviteclients" => $this->inviteClientUsers($project->projectid),
                        "invitemanagers" => $this->inviteManagerUsers($project->projectid),
                        "lastupdate" => (isset($commentArray['created_at']) ? 'Last updated ' . date("M d D h:i a", strtotime($this->general->converttimezoneFromUTCWTZ($commentArray['created_at']))) : 'Project created at ' . date("M d D h:i a", strtotime($project->created_at))),
                        "prevFirstAlpha" => ($prevFirstAlpha != $firstAlpha ? '' : $firstAlpha),
                    );
                }
                $this->newdata[$this->i] = (object) $array;
                $this->i++;
                $prevFirstAlpha = $firstAlpha;
            }
        }
        return $this->newdata;
    }

    public function getAjaxArchivedProjects($request,$companyId = false)
    {
        $perpage = (int)$request->page + 1;
        $this->i = 0;
        $this->newdata = array();
        $array = array();
        $strQuery = '';
        $allProjectIds = array();

        $projects = DB::table('projects')
            ->join('invites', 'projects.projectid', '=', 'invites.projectid')
            ->where([['invites.userid', Auth::user()->id], ['invites.deleted_at', '0000-00-00 00:00:00'], ['projects.archived', 1], ['projects.companyid', $companyId], ['projects.deleted_by', 0]])
            ->orderBy('projects.projectname')
            ->limit(15)
            ->offset($perpage)
            ->get()->toArray();

        if (count($projects) > 0) {
            $prevFirstAlpha = '';
            foreach ($projects as $index=>$project) {
                $totalPie = 0;
                $totalTasks = DB::table('tasks')->where([['projectid', $project->projectid], ['labelid', '!=', 0], ['deleted_at', null]])->count();
                $totalOpenTasks = DB::table('tasks')->where([['projectid', $project->projectid], ['completed', 0], ['labelid', '!=', 0], ['deleted_at', null]])->count();
                $totalClose = $totalTasks - $totalOpenTasks;

                $totalTime = DB::select("SELECT  SEC_TO_TIME( SUM( TIME_TO_SEC( `working_time` ) ) ) AS timetdlSum FROM todo_comments where projectid = " . $project->projectid);
                $commentInfo = DB::table('comments')->where('projectid', $project->projectid)->orderBy('commentid', 'desc')->first();
                $commentArray = json_decode(json_encode($commentInfo), true);

                if(array_key_exists($index + 1, $projects )) {
                    $nextProjectId = $projects[$index+1]->projectid;
                    $nextAlpha = strtoupper(substr($projects[$index+1]->projectname, 0, 1));
                 } 

                $firstAlpha = strtoupper(substr($project->projectname, 0, 1));
                $array = array(
                    "projectid" => $project->projectid,
                    "nextprojectid" => $nextProjectId,
                    "nextAlpha" => $nextAlpha,
                    "projectname" => $project->projectname,
                    "seoname" => $project->seoname,
                    "seourl" => $project->seourl,
                    "projectstatus" => DB::table('projects_status')->where([['projectstatusid', $project->projectstatus]])->value('statusname'),
                    "firstalpha" => $firstAlpha,
                    "timeentry" => $project->timeentry,
                    "favourite" => $project->favourite,
                    "created_at" => $project->created_at,
                    "totaltime" => $totalTime[0]->timetdlSum,
                    "totaltasks" => $totalTasks,
                    "totalopentasks" => $totalOpenTasks,
                    "lastupdate" => (isset($commentArray['created_at']) ? 'Last updated ' . date("M d D h:i a", strtotime($this->general->converttimezoneFromUTCWTZ($commentArray['created_at']))) : 'Project created at ' . date("M d D h:i a", strtotime($project->created_at))),
                    "prevFirstAlpha" => ($prevFirstAlpha != $firstAlpha ? '' : $firstAlpha),
                ); 
                $this->newdata[$this->i] = (object) $array;
                $this->i++;
                $prevFirstAlpha = $firstAlpha;
            }
        }
        return $this->newdata;
    }

    private function inviteUsers($projectId)
    {
        $this->j = 0;
        $this->newdata1 = array();
        $array = array();
        $array4 = array();

        $allUsers = array();
        $invites = DB::table('invites')
        ->where([['projectid', $projectId],['invitetype', 'T'], ['deleted_at', '0000-00-00 00:00:00']])
        ->limit(9)
        ->get();
        if (count($invites) > 0) {
            foreach ($invites as $invite) {
                $userInfo = DB::table('users')->where([['id', $invite->userid], ['isactive', 1]])->first();
                if ($invite->userid != '' && isset($userInfo->id)) {
                    $array = array(
                        "id" => $userInfo->id,
                        "name" => trim($userInfo->firstname) . " " . trim($userInfo->lastname),
                        "logoname" => substr($userInfo->firstname,0,1)."".substr($userInfo->lastname,0,1),
                        "profilepic" => $userInfo->profilepic,
                        "invitetype" => $invite->invitetype,
                    );
                    if (!in_array($userInfo->id, $array4)) {
                        $array4[] = $userInfo->id;
                        $this->newdata1[$this->j] = (object) $array;
                        $this->j++;
                    }
                }
            }
        }
        return $this->newdata1;
    }

    private function inviteClientUsers($projectId)
    {
        $userNames = '';
        $allUsers = array();
        $inviteClientUserArr = DB::table('invites')->where([['projectid', $projectId],['invitetype', 'C'], ['deleted_by', '0']])->pluck('userid')->toArray();
        if(!empty($inviteClientUserArr)){
            $userNames = $this->getUserNames(implode(",", $inviteClientUserArr));
        }
        return $userNames;
    }

    private function inviteManagerUsers($projectId)
    {
        $userNames = '';
        $allUsers = array();
        $inviteManagerUserArr = DB::table('invites')->where([['projectid', $projectId],['manager', 1], ['deleted_by', '0']])->pluck('userid')->toArray();
        if(!empty($inviteManagerUserArr)){
            $userNames = $this->getUserNames(implode(",", $inviteManagerUserArr));
        }
        return $userNames;
    }

    private function getUserNames($notifyUserIds)
    {
        $userNames = '';
        $notifyUsers = DB::select("select firstname, lastname from todo_users where id in( " . $notifyUserIds . " ) and isactive = 1");
        if (count($notifyUsers) > 0) {
            foreach ($notifyUsers as $notifyUser) {
                $allUserNames[] = $notifyUser->firstname . " " . $notifyUser->lastname;
            }
            $userNames = implode(", ", $allUserNames);
        }
        return $userNames;
    }

    public function getAllClients($companyId = false)
    {
        //Assign also includes in notify users 10-01-2018
        $clientUIdArr = DB::table('projects')
            ->join('invites', 'projects.projectid', '=', 'invites.projectid')
            ->where([['projects.companyid', $companyId], ['projects.archived', 0], ['projects.deleted_by', 0], ['invites.invitetype', 'C'], ['invites.deleted_at', '0000-00-00 00:00:00']])
            ->pluck('invites.userid')->toArray();
        $clientUId = array_unique($clientUIdArr);
        $users = DB::table('users')
            ->where('isactive', 1)
            ->whereIn('id', $clientUId)
            ->select('id', 'firstname', 'lastname')->get();
        return $users;
        //end
    }

    public function getAllManagers($companyId = false)
    {
        //Assign also includes in notify users 10-01-2018
        $clientUIdArr = DB::table('projects')
            ->join('invites', 'projects.projectid', '=', 'invites.projectid')
            ->where([['projects.companyid', $companyId], ['projects.archived', 0], ['projects.deleted_by', 0], ['invites.manager', '1'], ['invites.deleted_at', '0000-00-00 00:00:00']])
            ->pluck('invites.userid')->toArray();
        $clientUId = array_unique($clientUIdArr);
        $users = DB::table('users')
            ->where('isactive', 1)
            ->whereIn('id', $clientUId)
            ->select('id', 'firstname', 'lastname')->get();
        return $users;
        //end
    }

    public function getProjectByQuery($query)
    {
        $project = DB::table('projects')->whereRaw($query)->first();
        return $project;
    }

    public function getTotalProjects($companyId = false, $archived = false)
    {
        $UId = (isset(Auth::user()->id) ? Auth::user()->id : Session::has('invitedNotRegUserId'));
        $totalProject = DB::table('projects')
                ->join('invites', 'projects.projectid', '=', 'invites.projectid')
                ->where([['invites.userid', $UId], ['invites.deleted_at', '0000-00-00 00:00:00'], ['projects.archived', $archived], ['projects.companyid', $companyId], ['projects.deleted_by', 0]])
                ->count();
        return $totalProject;
    }

    public function getProjectsByQuery($companyId = false,$archived = false)
    {
        $this->i = 0;
        $this->newdata = array();
        $array = array();
        $strQuery = '';
        $allProjectIds = array();
        $projectStatusArr = array("Presentation", "Accepted", "Launched", "Completed", "Maintenance");

        $projects = DB::table('projects')
            ->join('invites', 'projects.projectid', '=', 'invites.projectid')
            ->where([['invites.userid', Auth::user()->id], ['invites.deleted_at', '0000-00-00 00:00:00'], ['projects.archived', $archived], ['projects.companyid', $companyId], ['projects.deleted_by', 0]])
            ->orderBy('projects.projectname')
            ->get()->toArray();

        if (count($projects) > 0) {
            $prevFirstAlpha = '';
            foreach ($projects as $project) {
                $totalTasks = DB::table('tasks')->where([['projectid', $project->projectid], ['labelid', '!=', 0], ['deleted_at', null]])->count();
                $totalOpenTasks = DB::table('tasks')->where([['projectid', $project->projectid], ['completed', 0], ['labelid', '!=', 0], ['deleted_at', null]])->count();
                $totalClose = $totalTasks - $totalOpenTasks;
                $totalTime = DB::select("SELECT  SEC_TO_TIME( SUM( TIME_TO_SEC( `working_time` ) ) ) AS timetdlSum FROM todo_comments where projectid = " . $project->projectid);
                $commentInfo = DB::table('comments')->where('projectid', $project->projectid)->orderBy('commentid', 'desc')->first();
                $commentArray = json_decode(json_encode($commentInfo), true);

                $array = array(
                    "projectid" => $project->projectid,
                    "projectname" => $project->projectname,
                    "seoname" => $project->seoname,
                    "seourl" => $project->seourl,
                    "projectstatus" => $projectStatusArr[$project->projectstatus],
                    "timeentry" => $project->timeentry,
                    "favourite" => $project->favourite,
                    "created_at" => $project->created_at,
                    "totaltime" => $totalTime[0]->timetdlSum,
                    "totaltasks" => $totalTasks,
                    "totalopentasks" => $totalOpenTasks,
                    "inviteclients" => $this->inviteClientUsers($project->projectid),
                    "invitemanagers" => $this->inviteManagerUsers($project->projectid),
                    "lastupdate" => (isset($commentArray['created_at']) ? 'Last updated ' . date("M d D h:i a", strtotime($this->general->converttimezoneFromUTCWTZ($commentArray['created_at']))) : 'Project created at ' . date("M d D h:i a", strtotime($project->created_at))),
                );
                $this->newdata[$this->i] = (object) $array;
                $this->i++;
            }
        }
        return $this->newdata;
    }




    public function removeInvite($request)
    {
        $id = 0;
        if ($request->inviteid > 0) {
            $inviteInfo = DB::table('invites')->where([['inviteid', $request->inviteid]])->first();

            $taskIdArr = DB::table('tasks')
                ->join('projects', 'tasks.projectid', '=', 'projects.projectid')
                ->where([['tasks.mastertask', 0], ['tasks.deleted_by', 0]])
                ->pluck('tasks.taskid')->toArray();
            $cvid = DB::table('assigns')
                ->where([['taskid', $request->companyid], ['userid', $inviteInfo->userid]])
                ->whereIn('taskid', $taskIdArr)
                ->update(['status' => 1, "deleted_at" => date("Y-m-d H:i:s")]);

            return DB::table('invites')->where([['inviteid', $request->inviteid]])->update(['deleted_by' => Auth::user()->id, 'deleted_at' => date("Y-m-d H:i:s")]);
        }
        return $id;
    }

    public function removeClientInvite($request)
    {
        $id = 0;
        if ($request->cinviteid > 0) {
            return DB::table('invites')->where([['inviteid', $request->cinviteid]])->update(['deleted_by' => Auth::user()->id, 'deleted_at' => date("Y-m-d H:i:s")]);
        }
        return $id;
    }

    public function projectManager($request){
        $id = 0;
        if (!empty($request->inviteid)) {
            $inviteInfo = DB::table('invites')->where('inviteid', '=', $request->inviteid)->first();
            if ($inviteInfo) {
                $uid = DB::table('invites')->where([['inviteid', $request->inviteid]])->update(["manager" => $request->manager, 'updated_at' => date("Y-m-d H:i:s")]);
                return "1";
            }
        }
        return "0";
    }

    public function projectInvite($request)
    {
        $inviteIds = array();
        $id = 0;
        $uid = 0;
        if (!empty($request->email)) {
            foreach ($request->email as $email) {
                $userid = DB::table('users')->where('email', '=', $email)->value('id');
                if ($userid > 0) {
                    $invitetype = DB::table('invites')->where([['userid', $userid], ['projectid', $request->projectid], ['deleted_at', '0000-00-00 00:00:00']])->value('invitetype');
                    if ($invitetype == 'C' || $invitetype == 'T') {
                        $uid = DB::table('invites')->where([['userid', $userid], ['projectid', $request->projectid], ['deleted_at', '0000-00-00 00:00:00']])->update(["invitetype" => $request->invitetype, 'updated_at' => date("Y-m-d H:i:s")]);
                    } else {
                        $data = array("projectid" => $request->projectid, "userid" => $userid, "invitetype" => $request->invitetype, "created_at" => date("Y-m-d H:i:s"), "created_by" => $request->created_by);
                        $id = DB::table('invites')->insertGetId($data);
                        if ($id > 0) {
                            $inviteIds[] = $userid;
                        }
                    }
                    //add user to company link table
                    $usercomInfo = DB::table('user_company_link')->where([['userid', $userid], ['companyid', $request->companyid], ['deleted_at', '0000-00-00 00:00:00']])->first();
                    if (empty($usercomInfo)) {
                        $dataLink = array("companyid" => $request->companyid, "userid" => $userid, "user_type" => '5', "created_at" => date("Y-m-d H:i:s"), "created_by" => Auth::user()->id);
                        $uclid = DB::table('user_company_link')->insertGetId($dataLink);
                    }
                    //End
                } else {
                    $name = explode("@", $email);
                    if (strpos($name[0], '.') == false) {
                        $firstname = ucfirst($name[0]);
                    } else {
                        $nameArray = explode(".", $name[0]);
                        $firstname = ucfirst($nameArray[0]);
                    }
                    $randomNumber = rand(1, 50);
                    $randomImage = 'image' . $randomNumber . ".jpg";
                    $data = array("firstname" => $firstname, "email" => $email, "profilepic" => $randomImage, 'remember_token' => $request->_token, "timezone" => $request->timezone, "created_at" => date("Y-m-d H:i:s"), "created_by" => $request->created_by);
                    $uid = DB::table('users')->insertGetId($data);
                    if ($uid > 0) {
                        $data = array("projectid" => $request->projectid, "userid" => $uid, "invitetype" => $request->invitetype, "created_at" => date("Y-m-d H:i:s"), "created_by" => $request->created_by);
                        $iid = DB::table('invites')->insertGetId($data);

                        //add to user company link table
                        $usercomInfo = DB::table('user_company_link')->where([['userid', $uid], ['companyid', $request->companyid], ['deleted_at', '0000-00-00 00:00:00']])->first();
                        if (empty($usercomInfo)) {
                            $dataLink = array("companyid" => $request->companyid, "userid" => $uid, "user_type" => '5', "created_at" => date("Y-m-d H:i:s"), "created_by" => Auth::user()->id);
                            $uclid = DB::table('user_company_link')->insertGetId($dataLink);
                        }

                        $confirmation_code = base64_encode(str_random(30) . "|" . $uid);
                        $profilepic = $uid . ".jpg";
                        copy('support/images/profileimg/' . $randomImage, 'support/images/profile_img/' . $profilepic);
                        copy('support/images/profileimg/' . $randomImage, 'support/images/profile_img/thum/' . $profilepic);
                        User::where(['id' => $uid])->update(['profilepic' => $profilepic, "confirmation_code" => $confirmation_code]);

                        $user = DB::table('users')->where('email', $email)->first();
                        $projectInfo = DB::table('projects')->where('projectid', $request->projectid)->first();
                        $createdByInfo = DB::table('users')->where('id', $projectInfo->created_by)->first();

                        $mailvar = ['createtByName' => $createdByInfo->firstname . " " . $createdByInfo->lastname, 'projectName' => $projectInfo->projectname, 'id' => $user->id, 'firstname' => $user->firstname, 'email' => $user->email, 'confirmation_code' => $user->confirmation_code, 'templateName' => 'emails.signUpInvitation'];

                        dispatch((new SendRequestEmail($mailvar))->delay(30 * 1));
                    }
                }
            }
        }

        if ($id == 0 && $uid > 0) {
            return "1";
        } else if ($id > 0 && ($uid > 0 || $uid == 0)) {
            $projectInfo = DB::table('projects')->where('projectid', $request->projectid)->first();
            $mailvar = ['mailText' => $request->mailtext, 'projectid' => $request->projectid, 'inviteIds' => $inviteIds, 'invitedId' => Auth::user()->id, 'templateName' => 'emails.projectInvitation'];
            dispatch((new SendRequestEmail($mailvar))->delay(30 * 1));
            return "1";
        } else {
            return "0";
        }
    }


    public function projectClientInvite($request)
    {
        $inviteIds = array();
        $id = 0;
        $uid = 0;
        $faultUserName = '';
        $userType = array();
        $checkUserType = array("1", "2");
        //$cnt = 0;
        if (!empty($request->cemail)) {
            foreach ($request->cemail as $email) {
                $cnt = 0;
                $userid = DB::table('users')->where('email', '=', $email)->value('id');
                if ($userid > 0) {
                    $userInfo = DB::table('users')->where('id', $userid)->first();
                    $usercomInfo = DB::table('user_company_link')->where([['userid', $userid], ['companyid', $request->companyid], ['deleted_at', '0000-00-00 00:00:00']])->first();
                    //add user to company link table
                    if (empty($usercomInfo)) {
                        $dataLink = array("companyid" => $request->companyid, "userid" => $userid, "user_type" => '3', "created_at" => date("Y-m-d H:i:s"), "created_by" => Auth::user()->id);
                        $uclid = DB::table('user_company_link')->insertGetId($dataLink);
                        $usercomInfo = DB::table('user_company_link')->where([['userid', $userid], ['companyid', $request->companyid], ['deleted_at', '0000-00-00 00:00:00']])->first();
                    } else {
                        $userType = explode(",", $usercomInfo->user_type);
                        foreach ($checkUserType as $val) {
                            if (in_array($val, $userType)) {
                                $cnt++;
                            }
                        }
                    }

                    if ($cnt == 0) {
                        $invite = DB::table('invites')->where([['userid', $userid], ['projectid', $request->projectid], ['invitetype', $request->invitetype], ['deleted_at', '0000-00-00 00:00:00']])->value('userid');
                        if (count($invite) == 0) {
                            //check user present in invite table as team
                            $invitetype = DB::table('invites')->where([['userid', $userid], ['projectid', $request->projectid], ['deleted_at', '0000-00-00 00:00:00']])->value('invitetype');
                            if ($invitetype == 'C' || $invitetype == 'T') {
                                $uid = DB::table('invites')->where([['userid', $userid], ['projectid', $request->projectid], ['deleted_at', '0000-00-00 00:00:00']])->update(["invitetype" => $request->invitetype, 'updated_at' => date("Y-m-d H:i:s")]);
                            } else {
                                //end
                                $data = array("projectid" => $request->projectid, "userid" => $userid, "invitetype" => $request->invitetype, "created_at" => date("Y-m-d H:i:s"), "created_by" => $request->created_by);
                                $id = DB::table('invites')->insertGetId($data);
                                if ($id > 0) {
                                    $inviteIds[] = $userid;
                                }
                            }
                            $newUserType = ($usercomInfo->user_type != '' ? $usercomInfo->user_type . ",3" : '3');
                            $newUserTypeUnique = implode(",", array_unique(explode(",", $newUserType)));
                            DB::table('user_company_link')->where([['usercompanyid', $usercomInfo->usercompanyid]])->update(['user_type' => (isset($newUserTypeUnique) ? $newUserTypeUnique : $usercomInfo->user_type), 'updated_at' => date("Y-m-d H:i:s")]);
                        }
                    } else {
                        if ($faultUserName == '') {
                            $faultUserName = $userInfo->firstname . ($userInfo->lastname != '' ? " " . $userInfo->lastname : '');
                        } else {
                            $faultUserName = $faultUserName . ", " . $userInfo->firstname . ($userInfo->lastname != '' ? " " . $userInfo->lastname : '');
                        }
                    }
                } else {
                    $name = explode("@", $email);
                    if (strpos($name[0], '.') == false) {
                        $firstname = ucfirst($name[0]);
                    } else {
                        $nameArray = explode(".", $name[0]);
                        $firstname = ucfirst($nameArray[0]);
                    }
                    $randomNumber = rand(1, 50);
                    $randomImage = 'image' . $randomNumber . ".jpg";
                    $data = array("firstname" => $firstname, "email" => $email, "profilepic" => $randomImage, 'remember_token' => $request->_token, "timezone" => $request->timezone, "created_at" => date("Y-m-d H:i:s"), "created_by" => $request->created_by);
                    $uid = DB::table('users')->insertGetId($data);
                    if ($uid > 0) {
                        $data = array("projectid" => $request->projectid, "userid" => $uid, "invitetype" => $request->invitetype, "created_at" => date("Y-m-d H:i:s"), "created_by" => $request->created_by);
                        $iid = DB::table('invites')->insertGetId($data);

                        //add to user company link table
                        $usercomInfo = DB::table('user_company_link')->where([['userid', $uid], ['companyid', $request->companyid], ['deleted_at', '0000-00-00 00:00:00']])->first();
                        if (empty($usercomInfo)) {
                            $dataLink = array("companyid" => $request->companyid, "userid" => $uid, "user_type" => '3', "created_at" => date("Y-m-d H:i:s"), "created_by" => Auth::user()->id);
                            $uclid = DB::table('user_company_link')->insertGetId($dataLink);
                        }

                        $confirmation_code = base64_encode(str_random(30) . "|" . $uid);
                        $profilepic = $uid . ".jpg";
                        copy('support/images/profileimg/' . $randomImage, 'support/images/profile_img/' . $profilepic);
                        copy('support/images/profileimg/' . $randomImage, 'support/images/profile_img/thum/' . $profilepic);
                        User::where(['id' => $uid])->update(['profilepic' => $profilepic, "confirmation_code" => $confirmation_code]);

                        $user = DB::table('users')->where('email', $email)->first();
                        $projectInfo = DB::table('projects')->where('projectid', $request->projectid)->first();
                        $createdByInfo = DB::table('users')->where('id', $projectInfo->created_by)->first();

                        $mailvar = ['createtByName' => $createdByInfo->firstname . " " . $createdByInfo->lastname, 'projectName' => $projectInfo->projectname, 'id' => $user->id, 'firstname' => $user->firstname, 'email' => $user->email, 'confirmation_code' => $user->confirmation_code, 'templateName' => 'emails.signUpInvitation'];
                        dispatch((new SendRequestEmail($mailvar))->delay(30 * 1));
                    }
                }
            }
        }
        if ($id == 0 && $uid > 0) {
            if ($faultUserName == '') {
                return "1|";
            } else {
                return "2|" . $faultUserName;
            }
        } else if ($id > 0 && ($uid > 0 || $uid == 0)) {
            $projectInfo = DB::table('projects')->where('projectid', $request->projectid)->first();
            $mailvar = ['mailText' => $request->mailtext, 'projectid' => $request->projectid, 'inviteIds' => $inviteIds, 'invitedId' => Auth::user()->id, 'templateName' => 'emails.projectClientInvitation'];
            dispatch((new SendRequestEmail($mailvar))->delay(10 * 1));
            if ($faultUserName == '') {
                return "1|";
            } else {
                return "2|" . $faultUserName;
            }
        } else if ($cnt > 0) {
            return "2|" . $faultUserName;
        } else {
            return "0";
        }
    }


    public function archivedProject($request)
    {
        $teid = 0;
        $projectInfo = DB::table('projects')->where([['projectid', $request->projectid]])->first();
        if ($projectInfo) {
            if ($projectInfo->created_by == Auth::user()->id) {
                $teid = DB::table('projects')->where(['projectid' => $request->projectid])->update(['archived' => $request->archive]);
            } else if (in_array(1, explode(",", $request->user_type)) || in_array(2, explode(",", $request->user_type))) {
                $teid = DB::table('projects')->where(['projectid' => $request->projectid])->update(['archived' => $request->archive]);
            } else {
                return "2";
            }
        }
        return $teid;
    }

    public function deleteProject($request)
    {
        $teid = 0;
        $projectInfo = DB::table('projects')->where([['projectid', $request->projectid]])->first();
        if ($projectInfo) {
            if (in_array(2, explode(",", $request->user_type))) {
                $pid = DB::table('projects')->where(['projectid' => $request->projectid])->update(['deleted_at' => date("Y-m-d H:i:s"), 'deleted_by' => Auth::user()->id]);
                if ($pid) {
                    $lid = DB::table('labels')->where(['projectid' => $request->projectid])->update(['deleted_at' => date("Y-m-d H:i:s"), 'deleted_by' => Auth::user()->id]);
                    $tid = DB::table('tasks')->where(['projectid' => $request->projectid])->update(['deleted_at' => date("Y-m-d H:i:s"), 'deleted_by' => Auth::user()->id]);
                    $cid = DB::table('comments')->where(['projectid' => $request->projectid])->update(['deleted_at' => date("Y-m-d H:i:s"), 'deleted_by' => Auth::user()->id]);
                    $nid = DB::table('notes')->where(['projectid' => $request->projectid])->update(['deleted_at' => date("Y-m-d H:i:s"), 'deleted_by' => Auth::user()->id]);
                    $iid = DB::table('invites')->where(['projectid' => $request->projectid])->update(['deleted_at' => date("Y-m-d H:i:s"), 'deleted_by' => Auth::user()->id]);
                }
            } else {
                return "2";
            }
        }
        return $pid;
    }

    public function favouriteProject($request)
    {
        $teid = 0;
        $projectInfo = DB::table('projects')->where([['projectid', $request->projectid]])->first();
        if ($projectInfo) {
            $teid = DB::table('projects')->where(['projectid' => $request->projectid])->update(['favourite' => $request->favourite]);
        }
        return $teid;
    }


    

    public function saveProject($request)
    {
        //New changes on 11-09-2017
        $inviteIds = array();
        $id = 0;
        $uid = 0;
        $faultUserName = '';
        $userType = array();
        $checkUserType = array("1", "2");
        //
        //Check for permission
        $userInfo = DB::table('users')->where('id', Auth::user()->id)->first();
        $createprojectDb = $userInfo->createproject;
        $found = false;
        $authUserType = DB::table('user_company_link')->where([['companyid', $request->companyid], ['userid', Auth::user()->id]])->value('user_type');
        $authUserTypes = explode(",", $authUserType);
        if (count($authUserTypes) > 0) {
            foreach ($authUserTypes as $usertype) {
                if ($usertype == 1 || $usertype == 2 || $createprojectDb == 1) {
                    $found = true;
                }
            }
            if ($found == false) {
                return "4";
            }
        }
        //end
        if(isset($request->projectid) && $request->projectid !=''){
            $upid = DB::table('projects')->where([['projectid', $request->projectid]])->update(['estimatecost'=>$request->estimatecost, 'projectrate'=>$request->projectrate, 'projecthour'=>$request->projecthour, 'totalestimatecost'=>$request->totalestimatecost, 'updated_at' => date("Y-m-d H:i:s")]);
            if(!empty($request->task_id) ){
                DB::delete('delete from todo_projects_estimate where projectid = '.$request->projectid.' and estimatetype="T"');
                $taskidctr = 0;
                foreach($request->task_id as $taskid){
                    $taskInfo = DB::table('tasks')->where('taskid',$taskid)->first();
                    if($request->taskrate[$taskidctr] != ''){
                        $data = array("projectid"=>$request->projectid,"estimatetype"=>'T', "entityid"=>$taskid, "rate"=>$request->taskrate[$taskidctr], "hours"=>$request->taskhour[$taskidctr], "created_at"=>date("Y-m-d H:i:s"), "created_by"=>$request->created_byproject);
                        $ieid = DB::table('projects_estimate')->insertGetId($data);
                    }
                    $taskidctr++;
                }
            }
            if(!empty($request->staff_id) ){
                DB::delete('delete from todo_projects_estimate where projectid = '.$request->projectid.' and estimatetype="U"');
                $staffidctr = 0;
                foreach($request->staff_id as $staffid){
                    $staffInfo = DB::table('users')->where('id',$staffid)->first();
                    if($request->staffrate[$staffidctr] != ''){
                        $data = array("projectid"=>$request->projectid,"estimatetype"=>'U', "entityid"=>$staffid, "rate"=>$request->staffrate[$staffidctr], "hours"=>$request->staffhour[$staffidctr], "created_at"=>date("Y-m-d H:i:s"), "created_by"=>$request->created_byproject);
                        $ieid = DB::table('projects_estimate')->insertGetId($data);
                    }
                    $staffidctr++;
                }
            }
            return ($upid ? $upid : 0);
        }else{
            //create project
            $seoName = DB::table('projects')->where('projectname', '=', trim($request->pprojectname))->value('seoname');
            $seoName = ($seoName != '' ? $this->general->seoName($seoName,'projects','projectid') : $this->general->getSeoName(trim($request->pprojectname)));

            $data = array('companyid' => $request->companyid, "projectname" => trim($request->pprojectname), "projectdescription" => $request->projectdescription, "projectdescriptionlink" => $this->link_it($request->projectdescription), "seoname" => $seoName, "seourl" => "project/" . $seoName, "created_at" => date("Y-m-d H:i:s"), "created_by" => $request->created_byproject);
            $pid = DB::table('projects')->insertGetId($data);
            //end
        }
        
        if ($pid) {
            // For local server
            if (!File::exists("public/img/comment_files/" . $seoName)) {
                File::makeDirectory("public/img/comment_files/" . $seoName, $mode = 0777, true, true);
                File::makeDirectory("public/img/comment_files/" . $seoName . "/list", $mode = 0777, true, true);
                File::makeDirectory("public/img/comment_files/" . $seoName . "/thum", $mode = 0777, true, true);
            }
            // End   

            //invite creator of this project 01-08-2018
            $inviteid = DB::table('invites')->where([['userid', Auth::user()->id], ['projectid', $pid], ['deleted_at', '0000-00-00 00:00:00']])->value('inviteid'); 
            if (!isset($inviteid) && $inviteid == '') {

                $usercompInfo = DB::table('user_company_link')->where([['companyid', $request->companyid], ['userid', Auth::user()->id],['deleted_at', '0000-00-00 00:00:00']])->first();

                $inviteCreatorData = array("projectid" => $pid, "userid" => Auth::user()->id,'invitetype'=>($usercompInfo->userrole == 0 ? 'T':'C'), "created_at" => date("Y-m-d H:i:s"), "created_by" => $request->created_byproject);
                $icid = DB::table('invites')->insertGetId($inviteCreatorData);
            }
             //end

            //invite company owner 25-01-2017
            $companyOwnerId = DB::table('companies')->where('companyid', '=', $request->companyid)->value('created_by');
            $inviteid = DB::table('invites')->where([['userid', $companyOwnerId], ['projectid', $pid], ['deleted_at', '0000-00-00 00:00:00']])->value('inviteid');
            if (!isset($inviteid) && $inviteid == '') {
                $inviteCompanyData = array("projectid" => $pid, "userid" => $companyOwnerId, "created_at" => date("Y-m-d H:i:s"), "created_by" => $request->created_byproject);
                $icid = DB::table('invites')->insertGetId($inviteCompanyData);
            }
            //end
            //invite other owners of this company 15-01-2018
            $userCompanyLinks = DB::table('user_company_link')->where('companyid', $request->companyid)->get();
            if (count($userCompanyLinks) > 0) {
                foreach ($userCompanyLinks as $userCompanyLink) {
                    $userTypeArr = ($userCompanyLink->user_type != '' ? explode(",", $userCompanyLink->user_type) : array());
                    if (in_array(2, $userTypeArr)) {
                        $inviteid = DB::table('invites')->where([['userid', $userCompanyLink->userid], ['projectid', $pid], ['deleted_at', '0000-00-00 00:00:00']])->value('inviteid');
                        if (!isset($inviteid) && $inviteid == '') {
                            $inviteCompanyData = array("projectid" => $pid, "userid" => $userCompanyLink->userid, "created_at" => date("Y-m-d H:i:s"), "created_by" => $request->created_byproject);
                            $icid = DB::table('invites')->insertGetId($inviteCompanyData);
                        }
                    }
                }
            }
            //end
            $inviteIds = array();
            $id = 0;
            $uid = 0;
            if (!empty($request->email)) {
                foreach ($request->email as $email) {
                    $userid = DB::table('users')->where('email', '=', $email)->value('id');
                    if ($userid > 0) {
                        $invite = DB::table('invites')->where([['userid', $userid], ['projectid', $pid]])->value('userid');
                        if ($invite == 0) {
                            $data = array("projectid" => $pid, "userid" => $userid, "created_at" => date("Y-m-d H:i:s"), "created_by" => $request->created_byproject);
                            $id = DB::table('invites')->insertGetId($data);
                            if ($id > 0) {
                                //add to user company link table
                                $usercomInfo = DB::table('user_company_link')->where([['userid', $userid], ['companyid', $request->companyid], ['deleted_at', '0000-00-00 00:00:00']])->first();
                                if (empty($usercomInfo)) {
                                    $dataLink = array("companyid" => $request->companyid, "userid" => $userid, "user_type" => '5', "created_at" => date("Y-m-d H:i:s"), "created_by" => Auth::user()->id);
                                    $uclid = DB::table('user_company_link')->insertGetId($dataLink);
                                }
                                $inviteIds[] = $userid;
                            }
                        }
                    } else {
                        $name = explode("@", $email);
                        if (strpos($name[0], '.') == false) {
                            $firstname = ucfirst($name[0]);
                        } else {
                            $nameArray = explode(".", $name[0]);
                            $firstname = ucfirst($nameArray[0]);
                        }
                        $data = array("firstname" => $firstname, "email" => $email, "profilepic" => '', 'remember_token' => $request->_token, "timezone" => $request->timezone, "created_at" => date("Y-m-d H:i:s"), "created_by" => $request->created_byproject);
                        $uid = DB::table('users')->insertGetId($data);
                        if ($uid > 0) {
                            $data = array("projectid" => $pid, "userid" => $uid, "created_at" => date("Y-m-d H:i:s"), "created_by" => $request->created_byproject);
                            $iid = DB::table('invites')->insertGetId($data);
                            //add to user company link table
                            $dataLink = array("companyid" => $request->companyid, "userid" => $uid, "user_type" => '5', "created_at" => date("Y-m-d H:i:s"), "created_by" => Auth::user()->id);
                            $uclid = DB::table('user_company_link')->insertGetId($dataLink);

                            $confirmation_code = base64_encode(str_random(30) . "|" . $uid);
                            User::where(['id' => $uid])->update(["confirmation_code" => $confirmation_code]);

                            $user = DB::table('users')->where('email', $email)->first();
                            $projectInfo = DB::table('projects')->where('projectid', $pid)->first();
                            $createdByInfo = DB::table('users')->where('id', $projectInfo->created_by)->first();

                            $mailvar = ['createtByName' => $createdByInfo->firstname . " " . $createdByInfo->lastname, 'projectName' => $projectInfo->projectname, 'id' => $user->id, 'firstname' => $user->firstname, 'email' => $user->email, 'confirmation_code' => $user->confirmation_code];

                            Mail::send('emails.signUpInvitation', ['mailvar' => $mailvar], function ($message) use ($mailvar) {
                                $message->to($mailvar['email'], 'New user')->subject("You've been added to the " . $mailvar['projectName'] . " project on todooos");
                            });
                        }
                    }
                }
            }
            // new add as on 11-09-2017
            if (!empty($request->cemail)) {
                foreach ($request->cemail as $email) {
                    $cnt = 0;
                    $userid = DB::table('users')->where('email', '=', $email)->value('id');
                    if ($userid > 0) {
                        $userInfo = DB::table('users')->where('id', $userid)->first();
                        $usercomInfo = DB::table('user_company_link')->where([['userid', $userid], ['companyid', $request->companyid], ['deleted_at', '0000-00-00 00:00:00']])->first();
                        //add user to company link table
                        if (empty($usercomInfo)) {
                            $dataLink = array("companyid" => $request->companyid, "userid" => $userid, "user_type" => '3', "created_at" => date("Y-m-d H:i:s"), "created_by" => Auth::user()->id);
                            $uclid = DB::table('user_company_link')->insertGetId($dataLink);
                            $usercomInfo = DB::table('user_company_link')->where([['userid', $userid], ['companyid', $request->companyid], ['deleted_at', '0000-00-00 00:00:00']])->first();
                        }else {
                            $userType = explode(",", $usercomInfo->user_type);
                            foreach ($checkUserType as $val) {
                                if (in_array($val, $userType)) {
                                    $cnt++;
                                }
                            }
                        }

                        if ($cnt == 0) {
                            $invite = DB::table('invites')->where([['userid', $userid], ['projectid', $pid], ['invitetype', $request->invitetype], ['deleted_at', '0000-00-00 00:00:00']])->value('userid');
                            if (!$invite) {
                                //DB::enableQueryLog();
                                //check user present in invite table as team
                                $teamInviteId = DB::table('invites')->where([['userid', $userid], ['projectid', $pid], ['invitetype', 'T'], ['deleted_at', '0000-00-00 00:00:00']])->value('inviteid');
                                if ($teamInviteId > 0) {
                                    DB::table('invites')->where([['inviteid', $teamInviteId]])->update(['deleted_at' => date("Y-m-d H:i:s")]);
                                }
                                //end
                                $data = array("projectid" => $pid, "userid" => $userid, "invitetype" => $request->invitetype, "created_at" => date("Y-m-d H:i:s"), "created_by" => $request->created_by);
                                $id = DB::table('invites')->insertGetId($data);
                                if ($id > 0) {
                                    $inviteIds[] = $userid;
                                }
                                $newUserType = ($usercomInfo->user_type != '' ? $usercomInfo->user_type . ",3" : '3');
                                $newUserTypeUnique = implode(",", array_unique(explode(",", $newUserType)));
                                DB::table('user_company_link')->where([['usercompanyid', $usercomInfo->usercompanyid]])->update(['user_type' => (isset($newUserTypeUnique) ? $newUserTypeUnique : $usercomInfo->user_type), 'updated_at' => date("Y-m-d H:i:s")]);
                                //print_r(DB::getQueryLog());
                            }
                        } else {
                            if ($faultUserName == '') {
                                $faultUserName = $userInfo->firstname . ($userInfo->lastname != '' ? " " . $userInfo->lastname : '');
                            } else {
                                $faultUserName = $faultUserName . ", " . $userInfo->firstname . ($userInfo->lastname != '' ? " " . $userInfo->lastname : '');
                            }
                        }
                    } else {
                        $name = explode("@", $email);
                        if (strpos($name[0], '.') == false) {
                            $firstname = ucfirst($name[0]);
                        } else {
                            $nameArray = explode(".", $name[0]);
                            $firstname = ucfirst($nameArray[0]);
                        }
                        $data = array("firstname" => $firstname, "email" => $email, "profilepic" =>'', 'remember_token' => $request->_token, "timezone" => $request->timezone, "created_at" => date("Y-m-d H:i:s"), "created_by" => $request->created_by);
                        $uid = DB::table('users')->insertGetId($data);
                        if ($uid > 0) {
                            $data = array("projectid" => $pid, "userid" => $uid, "invitetype" => $request->invitetype, "created_at" => date("Y-m-d H:i:s"), "created_by" => $request->created_by);
                            $iid = DB::table('invites')->insertGetId($data);

                            //add to user company link table
                            $usercomInfo = DB::table('user_company_link')->where([['userid', $uid], ['companyid', $request->companyid], ['deleted_at', '0000-00-00 00:00:00']])->first();
                            if (empty($usercomInfo)) {
                                $dataLink = array("companyid" => $request->companyid, "userid" => $uid, "user_type" => '3', "created_at" => date("Y-m-d H:i:s"), "created_by" => Auth::user()->id);
                                $uclid = DB::table('user_company_link')->insertGetId($dataLink);
                            }

                            $confirmation_code = base64_encode(str_random(30) . "|" . $uid);
                            User::where(['id' => $uid])->update(["confirmation_code" => $confirmation_code]);

                            $user = DB::table('users')->where('email', $email)->first();
                            $projectInfo = DB::table('projects')->where('projectid', $pid)->first();
                            $createdByInfo = DB::table('users')->where('id', $projectInfo->created_by)->first();

                            $mailvar = ['createtByName' => $createdByInfo->firstname . " " . $createdByInfo->lastname, 'projectName' => $projectInfo->projectname, 'id' => $user->id, 'firstname' => $user->firstname, 'email' => $user->email, 'confirmation_code' => $user->confirmation_code, 'templateName' => 'emails.signUpInvitation'];
                            dispatch((new SendRequestEmail($mailvar))->delay(30 * 1));
                        }
                    }
                }
            }
            //
            if ($id == 0 && $uid > 0) {
                return "1|" . $seoName;
            } else if ($pid != 0 && $uid == 0 && $id == 0) {
                return "1|" . $seoName;
            } else if ($id > 0 && ($uid > 0 || $uid == 0)) {
                $projectInfo = DB::table('projects')->where('projectid', $pid)->first();
                $mailvar = ['mailText' => $request->mailtext, 'projectid' => $pid, 'inviteIds' => $inviteIds, 'invitedId' => Auth::user()->id, 'templateName' => 'emails.projectInvitation'];
                dispatch((new SendRequestEmail($mailvar))->delay(1 * 1));
                return "1|" . $seoName;
            } else {
                return "0|0";
            }

        } else {
            return "0|0";
        }
    }

    public function projectUpdate($request)
    {
        //update project name
        $pid = 0;
        $projectInfo = DB::table('projects')->where('projectid', $request->editprojectid)->first();
        if($projectInfo->projectname == $request->editprojectname){
            $pid = DB::table('projects')->where([['projectid', $request->editprojectid]])->update(["projectdescription" => $request->editprojectdesc, "projectdescriptionlink" => $this->link_it($request->editprojectdesc), "updated_at" => date("Y-m-d H:i:s"), "updated_by" => Auth::user()->id]); 
            if($pid){
                return $pid."|".$projectInfo->seoname;
            }
            return $pid;
        }

        $seoName = DB::table('projects')->where('projectname', '=', trim($request->editprojectname))->value('seoname');
        $seoName = ($seoName != '' ? $this->general->seoName($seoName,'projects','projectid') : $this->general->getSeoName(trim($request->editprojectname)));

        $pid = DB::table('projects')->where([['projectid', $request->editprojectid]])->update(["projectname" => trim($request->editprojectname), "projectdescription" => $request->editprojectdesc, "projectdescriptionlink" => $this->link_it($request->editprojectdesc), "seoname" => $seoName, "seourl" => "project/" . $seoName, "updated_at" => date("Y-m-d H:i:s"), "updated_by" => Auth::user()->id]);

        if ($pid) {
            if (File::exists("public/img/comment_files/" . $projectInfo->seoname)) {
                File::moveDirectory("public/img/comment_files/" . $projectInfo->seoname, "public/img/comment_files/" . $seoName);
            }

            //update tasks db
            $tasks = DB::table('tasks')->where('projectid', $projectInfo->projectid)->get()->toArray();
            if (count($tasks) > 0) {
                foreach ($tasks as $task) {
                    if ($task->labelid == 0) {
                        $tid = DB::table('tasks')->where([['taskid', $task->taskid]])->update(["seourl" => "project/" . $seoName . "/discussion" . "/" . $task->seoname]);
                    } else {
                        $labelSeoName = DB::table('labels')->where('labelid', $task->labelid)->value('seoname');
                        $tid = DB::table('tasks')->where([['taskid', $task->taskid]])->update(["seourl" => "project/" . $seoName . "/todolist" . "/" . $labelSeoName . "/todo" . "/" . $task->seoname]);
                    }
                }
            }
            //end

            //update labels db
            $labels = DB::table('labels')->where('projectid', $projectInfo->projectid)->get()->toArray();
            if (count($labels) > 0) {
                foreach ($labels as $label) {
                    $lid = DB::table('labels')->where([['labelid', $label->labelid]])->update(["seourl" => "project/" . $seoName . "/todolist" . "/" . $label->seoname]);
                }
            }
            //end
            //update notes db
            $notes = DB::table('notes')->where('projectid', $projectInfo->projectid)->get()->toArray();
            if (count($notes) > 0) {
                foreach ($notes as $note) {
                    $nid = DB::table('notes')->where([['noteid', $note->noteid]])->update(["seourl" => "project/" . $seoName . "/note" . "/" . $note->seoname]);
                }
            }
            //end

            //update comments db
            $comments = DB::table('comments')->where('projectid', $projectInfo->projectid)->get()->toArray();
            if (count($comments) > 0) {
                foreach ($comments as $comment) {
                    $taskSeoName = DB::table('tasks')->where('taskid', $comment->taskid)->value('seoname');
                    if ($comment->labelid == 0) {
                        $tid = DB::table('comments')->where([['commentid', $comment->commentid]])->update(["seourl" => "project/" . $seoName . "/discussion" . "/" . $taskSeoName . "#" . $comment->commentid]);
                    } else {
                        $labelSeoName = DB::table('labels')->where('labelid', $comment->labelid)->value('seoname');

                        $tid = DB::table('comments')->where([['commentid', $comment->commentid]])->update(["seourl" => "project/" . $seoName . "/todolist" . "/" . $labelSeoName . "/todo" . "/" . $taskSeoName . "#" . $comment->commentid]);
                    }
                }
            }
            //end

            //update files db
            $files = DB::table('files')->where('projectid', $projectInfo->projectid)->get()->toArray();
            if (count($files) > 0) {
                foreach ($files as $file) {
                    $fid = DB::table('files')->where([['fileid', $file->fileid]])->update(["foldername" => $seoName ]);
                }
            }
            //end

            // add to project history
            $dataps = array("companyid"=>$projectInfo->companyid, "projectid" => $projectInfo->projectid, "comment" => '', "oldprojectstatus" => $projectInfo->projectname, "newprojectstatus" => $request->editprojectname, "oldseoname" => $projectInfo->seoname, "newseoname" => $seoName, "action" => 'projectedit', "created_at" => date("Y-m-d H:i:s"), "created_by" => Auth::user()->id);
            $phid = DB::table('projects_history')->insertGetId($dataps);
            //end

            // send mail to all invite users 
            $inviteUserIdArr = DB::table('invites')->where([['projectid', $projectInfo->projectid],['deleted_at','0000-00-00 00:00:00']])->pluck('userid')->toArray();;
            if(!empty($inviteUserIdArr)){

                $profilepic = Auth::user()->profilepic;
                $projecteditby = Auth::user()->firstname." ".Auth::user()->lastname;

                $inviteUserIdArr = array_unique($inviteUserIdArr);
                $userNames = $this->getUserNames(implode(",", $inviteUserIdArr));

                $projectUrl = "project/" . $seoName;

                $mailSubject = "Project name change from " . $projectInfo->projectname . " to " . $request->editprojectname;

                $mailvar = ['profilepic'=>$profilepic, 'projecteditby'=>$projecteditby, 'oldprojectname' => $projectInfo->projectname, 'newprojectname' => $request->editprojectname, 'notifyUserArray' => $inviteUserIdArr, 'userNames' => $userNames, 'seoUrl' => $projectUrl, 'templateName' => 'emails.todoProjectEdit', 'mailSubject' => $mailSubject];
                dispatch((new SendRequestEmail($mailvar))->delay(10 * 1));
            }
            
            // end

        }
        return $pid . "|" . $seoName;
    }

    




    private function getCommentLists($projectId = false,$prevDate = false, $userId = false){
        $this->l = 0;
        $this->newdata3 = array();
        $array = array();
        $inviteUserArr = array();
        $inviteUsers = $this->invitedUser($projectId);

        if($inviteUsers != ''){
            $inviteUserArr = explode(",",$inviteUsers);
            $inviteUserArr = array_diff($inviteUserArr,array($userId) );
            $inviteUsers = implode(",",$inviteUserArr);
        }

        $projectInfo = DB::table('projects')->where('projectid', $projectId)->first();
        $comments = DB::select("select max(commentid) commentid, taskid, projectid, labelid, max(created_at) created_at, created_by from todo_comments where projectid = " . $projectId . " and description !='' and created_by in (" . $inviteUsers . ") and created_at between '".date("Y-m-d H:i:s",strtotime($prevDate." 00:00:00"))."' and '".date("Y-m-d H:i:s",strtotime($prevDate." 23:59:59"))."' and deleted_at is NULL group by taskid order by commentid desc ");
        if (count($comments) > 0) {
            foreach ($comments as $comment) {
                $commentseoUrl = "";
                $task = DB::table('tasks')->where([['taskid', $comment->taskid], ['deleted_at', null]])->first();
                if (!empty($task)) {
                    $commentCreatedBy = DB::table('comments')->where('commentid', $comment->commentid)->value('created_by');
                    $taskseoUrl = "/project/" . $projectInfo->seoname . "/todo/" . $task->seoname;
                    $commentseoUrl = "/project/" . $projectInfo->seoname . "/todo/" . $task->seoname . "#" . $comment->commentid;
                    $taskArray = json_decode(json_encode($task), true);
                    $userInfo = DB::table('users')->where('id', $commentCreatedBy)->first();
                    $userArray = json_decode(json_encode($userInfo), true);
                    $array = array(
                        "commentid" => $comment->commentid,
                        "taskname" => $taskArray['taskname'],
                        "projectid" => $comment->projectid,
                        "labelid" => $comment->labelid,
                        "created_at" => $this->general->converttimezoneFromUTCWTZ($comment->created_at),
                        "taskseourl" => $taskseoUrl,
                        "seourl" => $commentseoUrl,
                        "username" => $this->getCommentUserNames($task->taskid,$inviteUsers,$prevDate),
                    );
                    $this->newdata3[$this->l] = (object) $array;
                    $this->l++;
                }
            }
        }
        return $this->newdata3;
    }

    private function getCommentUserNames($taskId = false, $inviteUsers = false,$prevDate = false)
    {
        $userNames = '';
        $allUserNameArr = array();
        $comments = DB::select("select distinct(created_by) created_by from todo_comments where taskid = ".$taskId." and created_by in (" . $inviteUsers . ") and created_at between '".date("Y-m-d H:i:s",strtotime($prevDate." 00:00:00"))."' and '".date("Y-m-d H:i:s",strtotime($prevDate." 23:59:59"))."' and deleted_at is NULL order by commentid desc ");
        if (count($comments) > 0) {
            foreach ($comments as $comment) {
                $userInfo = DB::table('users')->where([['id', $comment->created_by], ['isactive', 1]])->first();
                if (count($userInfo) > 0) {
                    $allUserNameArr[] = trim($userInfo->firstname).($userInfo->lastname != '' ? " ".trim($userInfo->lastname) : "") ;
                }
            }
            $userNames = (!empty($allUserNameArr) ? implode(", ", $allUserNameArr) : '');
        }
        return $userNames;
    }

}
