@extends('layouts.authprojectwleft')
@section('pageTitle')
To-do details
@stop
@section('styles') 
{!! Html::style('public/css/blueimp-gallery.min.css')!!}
@stop
@section('content')
  <div id="overlaydiv">
    <div class="commentTop">
      <div class="customCheckBox">
        @if($task->archived == 0 && $task->deleted_at =='' && $task->labelid !=0) 
            <input type="checkbox" {{ ($task-> completed == 1 ? 'checked' : '')}} name="complete" id="taskcomplete-{{ $task->taskid
            }}"><span class="checkTick"></span>
        @endif
      </div>
      <div class="commentTopText">
        <div class="commentTopTextTop">
          <h5>{!! $task->taskname !!}</h5>
          <span class="badge badge-secondary">
              <a style="cursor:pointer;" id="uname-{{ $task->taskid }}" class="popoverTrigger">{{
                  $task->usernames }} {!! ($task->taskenddate != NULL ? date("d F Y",strtotime($task->taskenddate)): '' ) !!}
              </a>
              <div class="popoverBox" id="ajaxtaskassign-{!! $task->taskid !!}" style="display:none;"> </div>
          </span>
        </div>
        @if($task->labelid !=0)
        <p>From the to-do list: <a class="text-primary" href="{{ url($task->labelurl)}}">{{ $task->labelname}}</a></p>
        @endif
      </div>
      <div id="commentIcons" class="commentIcons">
        @if(in_array(1,$companyInfo->user_type) || in_array(2,$companyInfo->user_type) || in_array(3,$companyInfo->user_type))
        <span class="popoverBoxRightHold">
            <a style="cursor:pointer;" id="edittodo"><i class="fas fa-edit"></i></a>
            <div class="popoverBox" id="todoeditpopup" style="display:none;"> 
                <div class="arrow-up"></div>
                <div class="popoverBoxClose" id="todoeditclosepop"><i class="far fa-times-circle"></i></div>
                <br>
                <form method="post" action="" id="frmtaskedit">
                    @csrf
                    <div>
                        <div class="form-group">
                            <input type="text" id="taskname" placeholder="To-do name" name="taskname" class="form-control" value="{{$task->taskname}}">
                        </div>
                    </div>
                    <div class='dropdown-divider'></div>
                    <div class='row'>
                        <div class='col-sm-12'> 
                            <button type="submit" name="submitedittname" id="submitedittname"  class="btn btn-primary">Save</button> 
                            <input type="hidden" name="taskid" id="taskid" value="{{ $task->taskid }}">
                            <input type="hidden" name="labelid" id="labelid" value="{{ $task->labelid }}">
                            <a style="cursor: pointer;" class="text-primary" id="closeeditpopup">Never mind</a>
                            <span class="loader" id="loader-{{ $task->taskid }}"></span>
                        </div>
                    </div>
                </form>
                <div id="msgtodorename" class=""></div>
            </div>
        </span>
        <span class="popoverBoxRightHold">
        @if(in_array(1,$companyInfo->user_type) || in_array(2,$companyInfo->user_type) || in_array(3,$companyInfo->user_type))  
        <a style="cursor:pointer;" id="movetodo"><i class="fas fa-arrows-alt"></i></a>
        @endif
        <div class="popoverBox" id="todomovepopup" style="display:none;"> 
            <div class="arrow-up"></div>
            <div class="popoverBoxClose" id="todomoveclosepop"><i class="far fa-times-circle"></i></div>
            <br>
            <form method="post" action="" id="frmtodomove">
                @csrf
                <div>
                    <div class="form-group">
                        <label>Move this to-do:</label>
                        <select class="js-example-tokenizerprojects form-control" id="moveprojectid" name="moveprojectid">
                            <option value="" selected>Choose a project…</option>
                            @if(isset($projects) && count($projects) > 0) 
                                @foreach($projects as $projectdb)
                                <option value="{{ $projectdb->projectid }}">{{ $projectdb->projectname }}</option>
                                @endforeach 
                            @endif
                        </select>
                    </div>
                </div>
                <div id="movetodolist" style="display: none;">
                    <div class="form-group">
                        <select class="js-example-tokenizertodolist form-control" id="movelabelid" name="movelabelid">
                        </select> 
                    </div>
                </div>
                <div class='row'>
                    <div class='col-sm-12'> 
                        <button type="submit" id="edittask" name="edittask" class="btn btn-primary">Move this to-do</button>
                        <input type="hidden" name="movetaskid" id="movetaskid" value="{{ $task->taskid }}">
                        <a style="cursor: pointer;" class="text-primary" id="closemovepopup">Never mind</a>
                        <span class="loader" id="loader-{{ $task->taskid }}"></span>
                    </div>
                </div>
            </form>
            <div id="msgmovetodo" class=""></div>
        </div>
        </span>
        <a style="cursor:pointer;" id="deletetodo-{!! $task->taskid.'|'.$task->labelid !!}"><i class="far fa-trash-alt"></i></a>
        @endif
      </div>
    </div>
    <div id="todopost">
    @if(count($comments) > 0) @foreach($comments as $comment)
    <div class="media commentsBox" id="deletecom-{{ $comment->commentid }}">
      @if($comment->profilepic != '')
        <img class="mr-3" src="{{ URL::asset('img/profile_img/thum/'.$comment->profilepic) }}" alt="{{ $comment->created_by}}">
      @else
        <img class="mr-3" src="{{ URL::asset('public/img/profileImg.jpg')}}" alt="{{ $comment->created_by}}">
      @endif
      @if($comment->status == 0)
      <div class="media-body">
        @if($comment->deleted_at != NULL)
          <h5 class="text-warning">{{ $comment->deletedtext}}</h5>
          <h6>{!! date("d M, Y",strtotime($comment->deleted_at)) !!}</h6>
        @else
          <h5 class="mt-0">{{ $comment->created_by}}  | {!! ($comment->working_time!=NULL? ' Time: '.$comment->working_time : '')!!}</h5>
          {!! $comment->description !!}
          <h6>{!! $comment->created_at !!}</h6>
          @if($comment->updated_at != NULL && $comment->updated_by != '')
            <h6 class="text-warning">Comment edited by {{ $comment->updated_by}} at {{ date("d M, Y h:i a",strtotime($comment->updated_at))}}</h6>
          @endif
          @if(count($comment->files) > 0) 
          <div class="row">
            @foreach($comment->files as $file) 
            <div class="col-sm-6 col-md-4 col-lg-4 col-xl-3">
              <div class="card fileType text-center">
                @if($file->filetypes == 'image') 
                  @if($file->filenewname!='' && file_exists('public/img/comment_files/'.$file->foldername.'/thum/'.$file->filenewname))
                    <div class="fileTypeImg"><a href="{!! URL::to('/download/'.$file->foldername.'/'.base64_encode($file->filenewname)) !!}"><img src="{{ Storage::disk('s3')->url('comment_files/'.$file->foldername.'/thum/'.$file->filenewname) }}" alt="{{ $file->created_by}}" title="{!! $file->filename !!}"></a></div>
                  @else
                    <div class="fileTypeImg">
                      @if($file->fileextension!='' && file_exists('public/img/iconimg/'.$file->fileextension.'.png'))
                        <img src="{{ URL::asset('img/iconimg/'.$file->fileextension.'.png') }}" alt="" title="{!! $file->filename !!}">
                      @else
                        <img src="{{ URL::asset('img/iconimg/_blank.png') }}" alt="">
                      @endif
                    </div>
                  @endif
                @elseif($file->filetypes == 'other')
                  @if($file->filenewname!='' && file_exists('public/img/comment_files/'.$file->foldername.'/'.$file->filenewname))
                  <div class="fileTypeImg">
                    <a href="{!! URL::to('/download/'.$file->foldername.'/'.base64_encode($file->filenewname)) !!}">
                      @if($file->fileextension!='' && file_exists('public/img/iconimg/'.$file->fileextension.'.png'))
                        <img src="{{ URL::asset('img/iconimg/'.$file->fileextension.'.png') }}" alt="" title="{!! $file->filename !!}">
                      @else
                        <img src="{{ URL::asset('img/iconimg/_blank.png') }}" alt="" title="{!! $file->filename !!}">
                      @endif
                    </a>
                  </div>
                  @else  
                  <div class="fileTypeImg">
                      <a href="{!! URL::to('/download/'.$file->foldername.'/'.base64_encode($file->filenewname)) !!}">
                        @if($file->fileextension!='' && file_exists('public/img/iconimg/'.$file->fileextension.'.png'))
                          <img src="{{ URL::asset('img/iconimg/'.$file->fileextension.'.png') }}" alt="" title="{!! $file->filename !!}">
                        @else
                          <img src="{{ URL::asset('img/iconimg/_blank.png') }}" alt="" title="{!! $file->filename !!}">
                        @endif
                      </a>
                  </div>  
                  @endif 
                @else 
                <div class="fileTypeImg">
                    @if($file->fileextension!='' && file_exists('public/img/iconimg/'.$file->fileextension.'.png'))
                    <img src="{{ URL::asset('img/iconimg/'.$file->fileextension.'.png') }}" alt=""> @else
                    <img src="{{ URL::asset('img/iconimg/_blank.png') }}" alt=""> @endif
                </div>  
                @endif
                <div class="card-body">
                  <h5 class="card-title">{!! $file->filename !!}</h5>
                  <h6 class="m-0">{!! $file->filesize !!}</h6>
                </div>
              </div>
            </div>
            @endforeach
          </div>
            @if(count($comment->files) > 1)
              <div class="text-center"><a href="{!! URL::to('/commentdownload/'.$comment->commentid) !!}" class="btn btn-primary">Download All</a></div>
            @endif
          @endif
      @endif 
      </div>
      @elseif($comment->status == 1)
      <div class="media-body">
        <h5 class="text-warning">{{ $comment->created_by}} Completed the to-do</h5>
        <h6>{!! date("d M, Y",strtotime($comment->completed_at)) !!}</h6>
      </div>
      @elseif($comment->status == 2)
      <div class="media-body">
        <h5 class="text-warning">{{ $comment->created_by}} Re-open the to-do</h5>
        <h6>{!! date("d M, Y",strtotime($comment->completed_at)) !!}</h6>
      </div>
      @endif
    </div>
    <div id="ajaxeditcomment-{!! $comment->commentid !!}"></div>
    @endforeach @endif  

    @if($task->archived == 0 && $task->deleted_at =='')
      <div id="ajaxcomment"></div>
      <div class="media commentsBox" id="user-documents-row">
        @if(Auth::user()->profilepic != '' && file_exists('public/img/profile_img/thum/'.Auth::user()->profilepic))
          <img class="mr-3" src="{{ URL::asset('img/profile_img/thum/'.Auth::user()->profilepic) }}" alt="{{Auth::user()->firstname}}">
        @else
          <img class="mr-3" src="{{ URL::asset('img/profile-img.jpg') }}" alt="{{Auth::user()->firstname}}">
        @endif
        <div class="media-body add-commentField">
          <div class="form-group">
            <input class="form-control add-comment" placeholder="Add Comment or Upload a file..." type="text">
          </div>
        </div>
      </div>
      
      <form method="post" action="" id="fileupload-0" class="fileupload" enctype="multipart/form-data">
        @csrf 
        <div id="addcomment" class="media commentsBox" style="display:none;">
          @if(Auth::user()->profilepic != '')
            <img class="mr-3" src="{{ URL::asset('img/profile_img/thum/'.Auth::user()->profilepic) }}" alt="{{Auth::user()->firstname}}">
          @else
            <img class="mr-3" src="{{ URL::asset('img/profile-img.jpg') }}" alt="{{Auth::user()->firstname}}">
          @endif
          <div class="media-body">
              <div class="commentDetailsBox">
                <div class="commentEditor">
                  <div class="form-group">
                      <textarea id="description" name="description" class="form-control"></textarea>
                  </div>
                </div>
                <div class="commentDetailsUpload">
                    <div id="dropzone-0" class="dropzone fade well">
                      <div class="clearfix">
                        <span class="filetext"> To attach files drag & drop here or </span>
                        <span class="filetext">
                            <a class="text-primary">
                                <u>select files from your computer…</u>
                                <input id="FileName" type="file" name="files[]" multiple>
                            </a>
                        </span>
                      </div>
                      <table role="presentation" class="table table-striped">
                          <tbody class="files"></tbody>
                      </table>
                    </div>
                </div>
                <div class="commentDetailsBottom">
                  <div class="d-flex flex-column flex-md-row bd-highlight align-items-end">
                    <div class="flex-fill">
                      <div class="row">
                        <div class="col-md-8 sideborder m-3">
                            @if($task->notifiednames == '')
                            <div class="emelcomment-text"> Email this comment to people on the project: </div>
                          @else
                          <p class="m-2">Your comment will be emailed to: <span id="emailnamelink"> {{ $task->notifiednames }}. <a id="emelcomment" style="cursor:pointer;"
                              class="text-primary">(Change)</a></span></p>
                          @endif    
                          <div class="commentHide">
                            <div class="m-2">
                              <p class="m-3">
                                <a id="selectall" style="cursor:pointer;" class="text-primary">Select All</a>
                                |
                                <a id="selectnone" style="cursor:pointer;" class="text-primary">Select None</a>
                              </p>
                            </div>
                            <div class="m-2">
                              <div class="row">
                                @foreach($inviteusers as $inviteuser)
                                <div class="col-md-6 m-2">
                                  <div class="customCheck">
                                      @if($task->notifiedids != '')
                                        <div class="customCheckBox">
                                            <input type="checkbox" {{ ( in_array($inviteuser->inviteuserid,$task->notifiedids)? 'checked' : '') }} name="inviteuserid[]" id="inviteuserid-{!! $inviteuser->inviteuserid!!}" value="{!! $inviteuser->inviteuserid!!}">
                                            <span class="checkTick"></span>
                                        </div>
                                        <label for="inviteuserid-{!! $inviteuser->inviteuserid!!}" class="form-check-label text-secondary">{!! $inviteuser->username!!}</label>
                                      @else
                                        <div class="customCheckBox">
                                            <input type="checkbox" name="inviteuserid[]" id="inviteuserid-{!! $inviteuser->inviteuserid!!}" value="{!! $inviteuser->inviteuserid!!}">
                                            <span class="checkTick"></span>
                                        </div>
                                        <label for="inviteuserid-{!! $inviteuser->inviteuserid!!}" class="form-check-label text-secondary">{!! $inviteuser->username!!}</label>
                                      @endif
                                  </div>
                                </div>
                                @endforeach
                              </div>
                            </div>
                            <div class="form-group">
                              <select class="js-example-basic-single-rrfuserid form-control"  name="rrfuserid[]" id="rrfuserid" multiple>
                                <option></option>
                                @if(isset($inviteusers) && count($inviteusers) > 0) @foreach($inviteusers as $inviteuser)
                                  <option value="{!! $inviteuser->inviteuserid!!}">{!! $inviteuser->username!!}</option>
                                  @endforeach @endif
                              </select>
                            </div>
                          </div>
                        </div>
                        <div class="col-md-4">
                          <p>&nbsp;</p>
                        </div>
                        <div class="col-md-12">
                            <p id="aloopuser" style="display:none;"><a style="cursor: pointer;" class="text-primary">Loop-in someone who isn't on the project</a> to share this by email only <a class="text-primary">(what is this?)</a>
                              <div id="divloopemail" style="display:none;">  
                                <div class="form-group">
                                  <select class="js-example-basic-single-loopemails form-control"  name="loopemails[]" id="loopemails" multiple>
                                      <option value="">The person you select will be notified by email</option>
                                      @if(isset($users) && count($users) > 0 ) 
                                        @foreach($users as $user) 
                                          @if(isset($comment->loopuseremails) && $comment->loopuseremails!='')
                                            <option value="{{ $user->email }}" {{ ( in_array($user->email,explode(",",$comment->loopuseremails))
                                              ? 'selected' : '') }}>{{ $user->firstname."
                                              ".$user->lastname }}</option>
                                          @else
                                            <option value="{{ $user->email }}">{{ $user->firstname." ".$user->lastname }}</option>
                                          @endif 
                                        @endforeach 
                                      @endif
                                  </select>
                                </div> 
                              </div> 
                            </p>
                        </div>
                      </div>
                    </div>
                    <div class="blankSpace"></div>
                    @if( $task->labelid != 0)
                    <div class="form-group time-field">
                      <div class="timeFieldArea">
                        <div class="d-flex flex-row bd-highlight align-items-center justify-content-end">
                          <div class="timeFieldIcon"><i class="far fa-clock"></i></div>
                              <input type="text" id="working_time" name="working_time" class="form-control timeField" placeholder="00:00" value="{!! $stoptimeentry !!}">
                        </div>
                      </div>
                    </div>
                    @endif
                  </div>
                </div>
              </div>
              <br>
              <input type="submit" id="submitcomment" class="btn btn-primary" value="Add Comment">
              <input type="button" class="btn btn-danger cancel-comment" value="Cancel" >
              <div id="msgdivcomment" class=""></div>
          </div>
        </div>
      </form>
    @endif
  </div>
  <!-- Todo History Start -->
  <div class="dropdown-divider m-5"></div>
  <div class="m-5">
      <h5 class="m-3"><a id="commenthistory-{!! $task->taskid !!}" style="cursor:pointer;" class="text-primary">By-the-minute history for this to-do...</a></h5>
      <div class="history" style="display:none;"></div>
  </div>
  <!-- Todo History End -->
</div>  
@stop()
@section('scripts')
{!! Html::script('js/commentlist.js') !!}
@stop
