<?php
namespace App\Http\Controllers;

use App\Models\Comment;
use App\Models\Company;
use App\Models\Project;
use App\Models\Task;
use App\User;
use Auth;
use Illuminate\Http\Request;
use Response;
use Session;

class ProjectController extends Controller
{
    protected $data = array();
    private $result = '';
    private $redirecturl = '';

    public function __construct(){
        //parent::__construct();
        $this->label = new Label;
        $this->comment = new Comment;
        $this->project = new Project;
        $this->company = new Company;
        $this->note = new Note;
        $this->task = new Task;
        $this->user = new User;
        $this->middleware(function ($request, $next) {
            if (Session::has('session_companyInfo')) {
                $companyInfo = Session::get('session_companyInfo');
                $this->data['companyInfo'] = $companyInfo;
                if(isset($companyInfo->companyid))
                {
                    if(isset($companyInfo->package->days) && $companyInfo->package->days == 'exp'){
                        if ($companyInfo->package->userid == Auth::user()->id){
                            abort(440);
                        }else{
                            abort(441);
                        }
                    }
                    $this->data['commentviews'] = $this->comment->getCommentView($companyInfo->companyid);
                    $this->data['totalcommentviews'] = $this->comment->getTotalCommentView($companyInfo->companyid);
                    $this->data['totalproject'] = $this->project->getTotalProjects($companyInfo->companyid,0);
                }
            }
            return $next($request);
        });
    }

    public function getProjectList(Request $request)
    {
        if ($request->ajax()) {
            abort(503);
        }
        if (Auth::check()) {
            $archived = 0;
            $this->data['clients'] = $this->project->getAllClients($this->data['companyInfo']->companyid);
            $this->data['managers'] = $this->project->getAllManagers($this->data['companyInfo']->companyid);
            $this->data['projects'] = $this->project->getProjects($this->data['companyInfo']->companyid,$archived);
            $this->data['listingtype'] = Auth::user()->listingtype;
            $this->data['totarchivedproject'] = $this->project->getTotalProjects($this->data['companyInfo']->companyid, 1);
            $this->data['totalproject'] = $this->project->getTotalProjects($this->data['companyInfo']->companyid, 0);
            return view('project.projectlist',$this->data);
        } else {
            return redirect('signin');
        }
    }

    public function getAjaxProjectList(Request $request)
    {
        if (Auth::check()) {
            $this->data['listingtype'] = Auth::user()->listingtype;
            $this->data['lastalpha'] = $request->lastalpha;
            $this->data['projects'] = $this->project->getAjaxProjects($request,$this->data['companyInfo']->companyid);
            return view('project.ajaxprojectlist', $this->data);
        } else {
            return redirect('signin');
        }
    }


    private function getCommon($request)
    {
        if (isset($request->seoname)) {
            $strQuery = " seoname = '".$request->seoname."'";
            if (!isset($this->data['companyInfo']->companyid)) {
                $this->data['project'] = $this->project->getProjectByQuery($strQuery);
                $this->data['companyInfo'] = $this->company->getCompanyInfo($this->data['project']->companyid);
            }
            
            $this->data['project'] = $this->project->getProjectByQuery($strQuery);
            if (empty($this->data['project'])) {
                abort(404);
            }
            $this->data['totaldiscussion'] = $this->task->getTotalDiscussion($this->data['project']->projectid);
            $this->data['totaltask'] = $this->task->getTotalTask($this->data['project']->projectid, $this->data['companyInfo']->user_type);
            $this->data['totalfiles'] = $this->comment->getTotalFile($this->data['project']->projectid);
            $this->data['totaltimeentry'] = $this->task->getTotalTimeEntry($this->data['project']->projectid);
            $this->data['inviteusers'] = $this->user->getInviteUserByPID($this->data['project']->projectid);
            $this->data['totalproject'] = $this->project->getTotalProjects($this->data['companyInfo']->companyid,0);
            $this->data['totalnotes'] = $this->note->getTotalNotes($this->data['project']->projectid);
        }  

    }

    public function getProjectDetails(Request $request)
    {
        if ($request->ajax()) {
            abort(503);
        }
        if (Auth::check()) {
            $archived = 0; 
            
            $this->getCommon($request);
            $this->data['project5updates'] = $this->task->getProjectUpdateList($this->data['project']->projectid, 'limit 5');
            $this->data['discussions'] = $this->task->getProjectDiscussions($this->data['project']->projectid, $searchQuery=false, $orderBy=false, 'limit 5');

            $this->data['notes'] = $this->note->getNoteList($this->data['project']->projectid);

            $orderBy = 'desc';
            $searchQuery = "deleted_at = '0000-00-00 00:00:00'";
            $limitQuery = "12";
            $this->data['projectfiles'] = $this->comment->getProjectFiles($this->data['project']->projectid, $searchQuery, $orderBy, $limitQuery);
            $this->data['labeltasks'] = $this->task->getLabelTaskList($this->data['project']->projectid, $this->data['companyInfo']->user_type);
            $this->data['totalcompletedtodo'] = $this->task->getTotalCompletedTodo($this->data['project']->projectid);
            $this->data['totalacrosslabel'] = $this->task->getTotalAcorssLabel($this->data['project']->projectid);
            $this->data['completedtodolists'] = $this->task->getCompletedtodolist($this->data['project']->projectid, $this->data['companyInfo']->user_type);
            // $this->data['pd'] = "1";
            $this->data['projects'] = $this->project->getProjectsByQuery($this->data['project']->companyid,$archived);
            return view('project.project',$this->data);
        } else {
            return redirect('signin');
        }
    }



    public function postProjectArchived(Request $request)
    {
        if (Auth::check()) {
            $returnData = false;
            $returnData = $this->project->archivedProject($request);
            return response()->json(array('sms' => $returnData));
        } else {
            return redirect('login');
        }
    }

    public function postProjectDelete(Request $request)
    {
        if (Auth::check()) {
            $returnData = false;
            $returnData = $this->project->deleteProject($request);
            return response()->json(array('sms' => $returnData));
        } else {
            return redirect('login');
        }
    }

    public function postProjectUnArchived(Request $request)
    {
        if (Auth::check()) {
            $returnData = false;
            $returnData = $this->project->unArchivedProject($request);
            return response()->json(array('sms' => $returnData));
        } else {
            return redirect('login');
        }
    }

    public function postProjectFavourite(Request $request)
    {
        if (Auth::check()) {
            $returnData = false;
            $returnData = $this->project->favouriteProject($request);
            return response()->json(array('sms' => $returnData));
        } else {
            return redirect('login');
        }
    }


    public function getTodolist(Request $request)
    {
        if ($request->ajax()) {
            abort(503);
        }
        if (Auth::check()) {
            $archived = 0;
            $this->getCommon($request);
            $this->data['labeltasks'] = $this->task->getLabelTaskList($this->data['project']->projectid, $this->data['companyInfo']->user_type);
            $this->data['inviteuserids'] = $this->user->getInviteUserByPID($this->data['project']->projectid);
            $this->data['allinviteuserids'] = $this->user->getAllInviteUsers($this->data['project']->projectid);
            $this->data['taskduedates'] = $this->task->getTaskDueDate($this->data['project']->projectid);
            //$this->data['labels'] = $this->task->getLabelTaskList($this->data['project']->projectid, $this->data['companyInfo']->user_type);
            $this->data['completedtodolists'] = $this->task->getCompletedtodolist($this->data['project']->projectid, $this->data['companyInfo']->user_type);
            $this->data['projects'] = $this->project->getProjectsByQuery($this->data['project']->companyid,$archived);
            return view('task.todolist', $this->data);
        } else {
            return redirect('login');
        }
    }


    public function getUserAllUpdates(Request $request)
    {
        if ($request->ajax()) {
            abort(503);
        }
        if (Auth::check()) {
            $archived = 0;
            $this->getCommon($request);
            $this->data['projects'] = $this->project->getProjectsByQuery($this->data['companyInfo']->companyid,$archived);
            $this->data['allupdates'] = $this->comment->getUserAllUpdates(base64_decode($request->userid), $this->data['companyInfo']->companyid);
            $this->data['user'] = $this->user->getUser(base64_decode($request->userid));
            return view('project.userallupdates', $this->data);
        } else {
            return redirect('login');
        }
    }

    public function getCompletedTodo(Request $request)
    {
        if ($request->ajax()) {
            abort(503);
        }
        if (Auth::check()) {
            $this->getCommon($request);
            $this->data['completedtodos'] = $this->task->getCompletedTodos($this->data['project']->projectid);
            return view('project.completed-todolist', $this->data);
        } else {
            return redirect('login');
        }
    }

    public function getDiscussions(Request $request)
    {
        if ($request->ajax()) {
            abort(503);
        }
        if (Auth::check()) {
            $archived = 0;
            $this->getCommon($request);
            $this->data['projects'] = $this->project->getProjectsByQuery($this->data['project']->companyid,$archived);
            $orderBy = "desc";
            $searchQuery = "";
            $limitQuery = "";
            $this->data['discussions'] = $this->task->getProjectDiscussions($this->data['project']->projectid, $searchQuery, $orderBy, $limitQuery);
            return view('task.discussion', $this->data);
        } else {
            return redirect('login');
        }
    }

    public function getAjaxDiscussionList(Request $request)
    {
        if (Auth::check()) {
            $orderBy = $request->orderby;
            $searchQuery = ($request->searchtext != "" ? ' and description like "%'.$request->searchtext.'%" ' : ' ');
            $limitQuery = "";
            $this->data['discussions'] = $this->task->getProjectDiscussions($request->projectid, $searchQuery, $orderBy, $limitQuery);
            return view('task.ajaxdiscussion', $this->data);
        } else {
            return redirect('signin');
        }
    }

    public function postSaveProject(Request $request)
    {
        if (Auth::check()) {
            $returnData = false;
            $returnData = $this->project->saveProject($request);
            return response()->json(array('sms' => $returnData));
        } else {
            return redirect('login');
        }
    }

    public function postClientAccess(Request $request)
    {
        if (Auth::check()) {
            $returnData = false;
            $returnData = $this->project->clientAccess($request);
            return response()->json(array('sms' => $returnData));
        } else {
            return redirect('login');
        }
    }

    public function postProjectStatus(Request $request)
    {
        if (Auth::check()) {
            $returnData = false;
            $returnData = $this->project->statusProject($request);
            return response()->json(array('sms' => $returnData));
        } else {
            return redirect('login');
        }
    }

    public function getProjectHistory(Request $request)
    {
        if (Auth::check()) {
            $this->data['project'] = $this->project->getProjectById($request->projectid);
            $this->data['projecthistorys'] = $this->project->getProjectHistory($request->projectid);
            return view('project.ajaxprojecthistory', $this->data);
        } else {
            return redirect('login');
        }
    }

    public function postProjectUpdate(Request $request)
    {
        if (Auth::check()) {
            $returnData = false;
            $returnData = $this->project->projectUpdate($request);
            return response()->json(array('sms' => $returnData));
        } else {
            return redirect('login');
        }
    }
    
}
